from django.urls import path
from .views import *


urlpatterns = [
   #  urls for login and register
   path('login/', LoginView.as_view(), name='login'),
   path('register/', RegistrationView.as_view(), name='register'),
   path('user/<int:pk>/', UserRetrieveUpdateDestroyAPIView.as_view(), name='upadate_user'), #update,partial update,delete,retrive customer and seller by id and their jwt token

   # admin urls 
   path('admin/register/', AdminRegistrationView.as_view(), name='admin_register'),
   path('admin/add_product/', AdminProductCreateView.as_view(), name='admin_add_product'),
   path('admin/list_all/', AdminListAllAPIView.as_view(), name='admin_list_all_data'),#get all data of all model 
   path('admin/<int:pk>/', AdminProductRetrieveUpdateDestroyAPIView.as_view(), name='admin_update_product'),#update,partial update,delete,retrive product by id with admin login
   
   # seller urls
   path('seller/add_product/', ProductCreateView.as_view(), name='add_product'),
   path('list_product/', ProductListAPIView.as_view(), name='list_product'),
   path('product/<int:pk>/', ProductRetrieveUpdateDestroyAPIView.as_view(), name='update_product'),#update,partial update,delete,retrive product by id by seller token

   # customer urls
   path('add_order/', OrderCreateView.as_view(), name='add_order'),
   path('list_order/', OrderListAPIView.as_view(), name='list_order'),
   path('order/<int:pk>/', OrderRetrieveUpdateDestroyAPIView.as_view(), name='update_order'),#update,partial update,delete,retrive order by id with customer token
]