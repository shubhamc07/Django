from rest_framework.permissions import BasePermission
from rest_framework.permissions import IsAuthenticatedOrReadOnly


# custom permission to only allow access to admin
class IsAdminUser(BasePermission):
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False

        return request.user.role == 'admin'

# custom permission to only allow access to seller
class IsSellerUser(BasePermission):
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False

        return request.user.role == 'seller'

# custom permission to only allow access to customer
class IsCustomerUser(BasePermission):
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        
        return request.user.role == 'customer'

# custom permission to only allow access to admin and Product Owner to get,update,delete the product deatils by given id
class IsSuperUserOrProductOwner(IsAuthenticatedOrReadOnly):

    def has_object_permission(self, request, view, obj):
        if request.method == 'GET':
            return request.user.role == 'admin' or obj.added_by == request.user
        if request.method in ('PUT', 'PATCH', 'DELETE'):
            return request.user.is_staff or obj.added_by == request.user
        return True   

# custom permission to only allow access to admin and Order Owner to get,update,delete the Order deatils by given id
class IsSuperUserOrOrderOwner(BasePermission):
   
    def has_object_permission(self, request, view, obj):
        if request.user.is_superuser:
            return True
        if request.method == 'GET':
            return request.user.role == 'admin' or obj.customer == request.user
        elif request.method in ('PUT', 'PATCH', 'DELETE'):
            return request.user.is_staff or obj.customer == request.user
        return True
    

# to update delete customer and seller role by their own token 
class IsCustomerOrSeller(BasePermission):

    def has_permission(self, request, view):
        return request.user.role in ['customer', 'seller']

    def has_object_permission(self, request, view, obj):
        return request.user == obj