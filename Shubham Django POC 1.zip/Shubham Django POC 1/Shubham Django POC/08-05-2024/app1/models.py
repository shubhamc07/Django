from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone
from django.core.exceptions import ValidationError
# Create your models here.

# model to add role field in user table 
class User(AbstractUser):
    ROLE_CHOICES = (
        ('admin', 'Admin'),
        ('seller', 'Seller'),
        ('customer', 'Customer'),
    )

    role = models.CharField(max_length=15,choices=ROLE_CHOICES)

# product model with ForeignKey relation with user model
class Product(models.Model):
    product_id = models.AutoField(primary_key=True)
    product_name = models.CharField(max_length=80)
    category = models.CharField(max_length=80)
    added_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='added_products',null=True,blank=True)

    def __str__(self) -> str:
        return self.product_name

# order model with ForeignKey relation with user model and product model
class Order(models.Model):
    order_id = models.AutoField(primary_key=True)
    customer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='orders_placed',null=True,blank=True)
    product = models.ForeignKey(Product, on_delete=models.CASCADE,null=True,blank=True)
    quantity = models.IntegerField(default=1)  #set default value of quantity to one
    order_date = models.DateTimeField(default=timezone.now)  #auto add placed order date

    def __str__(self) -> str:
        return self.product.product_name
