from rest_framework import serializers
from .models import User,Product,Order

# Serializer for login
class LoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField()

# Serializer for Registration
class RegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'email', 'role', 'password']
        extra_kwargs = {'password': {'write_only': True}}

    # to create user from given data
    def create(self, validated_data):
        user = User.objects.create_user(**validated_data)
        return user
    
    # to check the given role is in choices
    def validate_role(self, value):
        if value not in dict(User.ROLE_CHOICES).keys():
            raise serializers.ValidationError("Invalid role.")
        return value
    
    # to check email is unique
    def validate_email(self, value):
        if User.objects.filter(email=value).exists():
            raise serializers.ValidationError("Email address already exists.")
        return value
    
    # to check password is 6 characters long
    def validate_password(self,value):
        if len(value) < 6:
            raise serializers.ValidationError("Password must be at least of 6 characters long")
        return value
    
# user serializer to update,delete and retrive customer and seller details 
class UserSerializer(serializers.ModelSerializer):
    first_name = serializers.CharField(required=False)
    last_name = serializers.CharField(required=False)
    username = serializers.CharField(required=False)
    password = serializers.CharField(required=False, write_only=True)

    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'username', 'password']

#to update and partial update data
    def update(self, instance, validated_data):
        instance.first_name = validated_data.get('first_name', instance.first_name)
        instance.last_name = validated_data.get('last_name', instance.last_name)
        instance.username = validated_data.get('username', instance.username)
        password = validated_data.get('password')
        if password:
            instance.set_password(password)
        instance.save()
        return instance

    
# serializers for product model
class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = '__all__'
    
    # to auto add id which we get from token of user in added by field in Product
    def create(self,validated_data):
        user = self.context['request'].user
        validated_data['added_by'] = user
        return super().create(validated_data)
    
    # to check category filed is not emapty
    def validate_category(self, value):
        if not value:
            raise serializers.ValidationError("category field is required.")
        return value
    
    # to check product_name filed is not emapty
    def validate_product_name(self, value):
        if not value:
            raise serializers.ValidationError("product_name field is required.")
        return value

# serializers for order model
class OrderSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source='product.product_name', read_only=True)
    class Meta:
        model = Order
        fields = ['order_id', 'customer', 'product', 'product_name', 'quantity', 'order_date']
    
     # to auto add id which we get from token of user in customer field in Order
    def create(self, validated_data):
        user = self.context['request'].user
        validated_data['customer'] = user
        return super().create(validated_data)
    
    # to check Quantity is not zero or negitive value
    def validate_quantity(self, value):
        if value <= 0:
            raise serializers.ValidationError("Quantity can not be zero or less than zero")
        return value

# serializer to get all models data
class UserDetailSerializer(serializers.ModelSerializer):
    added_products = ProductSerializer(many=True, read_only=True)
    orders_placed = OrderSerializer(many=True, read_only=True)

    class Meta:
        model = User
        fields = ['id', 'username', 'role', 'added_products', 'orders_placed']
