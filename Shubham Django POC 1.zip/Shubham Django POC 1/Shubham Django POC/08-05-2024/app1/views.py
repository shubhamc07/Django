from django.shortcuts import render
from .models import User,Product,Order
from .serializers import ProductSerializer,OrderSerializer,LoginSerializer,RegistrationSerializer,UserDetailSerializer,UserSerializer
from rest_framework import generics
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth import authenticate
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.authentication import BasicAuthentication
from .custompermissions import IsAdminUser, IsCustomerUser, IsSuperUserOrProductOwner ,IsSellerUser,IsSuperUserOrOrderOwner,IsCustomerOrSeller
# Create your views here.


# Admin Registration
class AdminRegistrationView(APIView):
    def post(self, request):
        serializer = RegistrationSerializer(data=request.data)
        if serializer.is_valid():
            role = serializer.validated_data['role']
            if role not in ['admin']:
                return Response({"Error": "Invalid role select role of admin"}, status=status.HTTP_400_BAD_REQUEST)
            
            if role == 'admin':
                admin_count = User.objects.filter(role='admin').count() #get the number of admin role persent in user model
                if admin_count >= 2:
                    return Response({"Error": "maximum number of admins reached"}, status=status.HTTP_400_BAD_REQUEST)

            serializer.save()
            return Response({"message": f"{serializer.data['role']} created successfully", "data": serializer.data}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# seller/customer Registration
class RegistrationView(APIView):
    def post(self, request):
        serializer = RegistrationSerializer(data=request.data)
        if serializer.is_valid():
            role = serializer.validated_data['role']

            if role not in ['seller', 'customer']:
                return Response({"error": "Invalid role select role between seller or customer"}, status=status.HTTP_400_BAD_REQUEST)
            
            serializer.save()
            return Response({"message": f"{role} created successfully", "data": serializer.data}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# login and jwt token geration
class LoginView(APIView):
    def post(self,request):
        data = request.data
        serializer = LoginSerializer(data=data)
        if not serializer.is_valid():
            return Response({
                'Error':serializer.errors
            },status.HTTP_400_BAD_REQUEST)
        
        user = authenticate(username = serializer.data['username'],password=serializer.data['password'])
        if not user:
            return Response({
                'Error':'Invalid credentials'
            },status.HTTP_400_BAD_REQUEST)
        
        refresh = RefreshToken.for_user(user)
        return  Response({'massage': f'{user.role},login Successfully','username': user.username,'id':user.id, 'role': user.role ,'access': str(refresh.access_token)},status.HTTP_201_CREATED)
    

# Only Seller and Customer who added their own data they can Upadte,Partial Update,Retrieve and Delete The Own Deatils With JWTAuthentication
class UserRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated,IsCustomerOrSeller]
    serializer_class = UserSerializer

    def get_queryset(self):
        return User.objects.all()

# Admin Can Add Products
class AdminProductCreateView(generics.CreateAPIView):
    authentication_classes = [BasicAuthentication]
    permission_classes = [IsAuthenticated,IsAdminUser]
    serializer_class = ProductSerializer

# Admin Can see all data of how added the product and how placed the order
class AdminListAllAPIView(generics.ListAPIView):
    authentication_classes = [BasicAuthentication]
    permission_classes = [IsAuthenticated,IsAdminUser]
    queryset = User.objects.all()
    serializer_class = UserDetailSerializer

# Admin Can Upadte,Partial Update,Retrieve and Delete The Product Deatils With Basic Authetication
class AdminProductRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = [BasicAuthentication]
    permission_classes = [IsAuthenticated, IsSuperUserOrProductOwner]
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

# Seller Can Add Product With JWTAuthentication
class ProductCreateView(generics.CreateAPIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated,IsSellerUser]
    serializer_class = ProductSerializer

# list all product anyone can see
class ProductListAPIView(generics.ListAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

# Only Seller who added the particular product can Upadte,Partial Update,Retrieve and Delete The Product Deatils With JWTAuthentication
class ProductRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated, IsSuperUserOrProductOwner]
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

# Only Customer Can Add Order With JWTAuthentication
class OrderCreateView(generics.CreateAPIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated,IsCustomerUser]
    serializer_class = OrderSerializer

# list all orders anyone can see
class OrderListAPIView(generics.ListAPIView):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer

# Only Customer who added the particular product can Upadte,Partial Update,Retrieve and Delete The Product Deatils With JWTAuthentication
class OrderRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated, IsSuperUserOrOrderOwner]
    queryset = Order.objects.all()
    serializer_class = OrderSerializer